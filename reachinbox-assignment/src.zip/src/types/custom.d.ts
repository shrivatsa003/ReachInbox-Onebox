declare module "imap-simple";
declare module "mailparser";
