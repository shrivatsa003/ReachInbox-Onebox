import express from "express";
import dotenv from "dotenv";
import cors from "cors";
dotenv.config();

import { syncAllEmails, searchEmails } from "./services/emailService";

const app = express();

// ✅ Enable JSON & CORS
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:5173", // frontend
    methods: ["GET", "POST", "PUT", "DELETE"],
  })
);

// ✅ Root route
app.get("/", (req, res) => {
  res.send("Server is running 🚀");
});

// 🔍 Search emails route (with pagination, sorting, and filters)
app.get("/search", async (req, res) => {
  try {
    const q = (req.query.q as string) || "";
    const account = req.query.account as string | undefined;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const sortParam = (req.query.sort as string) || "date:desc";

    if (!q.trim()) {
      return res.status(400).json({ error: "Missing query parameter 'q'" });
    }

    // Extract sort field and order
    const [sortField, sortOrder] = sortParam.split(":");
    const from = (page - 1) * limit;

    // Fetch results
    const results = await searchEmails(q, account, {
      from,
      size: limit,
      sort: [{ [sortField]: { order: sortOrder as "asc" | "desc" } }],
    });

    // 🧹 Clean and normalize response
    const cleaned = results.map((email: any) => {
      const source = email._source || email;
      return {
        id: email._id || source.id || null,
        account: source.account || "Unknown",
        from: source.from || "Unknown sender",
        subject: source.subject || "(No Subject)",
        date: source.date || "N/A",
        snippet: (source.text || "").substring(0, 120) + "...",
      };
    });

    console.log(`✅ Found ${results.length} emails for query "${q}"`);
    res.json({
      query: q,
      page,
      limit,
      sort: sortParam,
      count: cleaned.length,
      results: cleaned,
    });
  } catch (err) {
    console.error("❌ Search error:", err);
    res.status(500).json({ error: "Search failed", details: err });
  }
});

const PORT = process.env.PORT || 5500;

// ✅ Start server and sync emails
app.listen(PORT, async () => {
  console.log("🚀 Starting email sync service...");
  try {
    await syncAllEmails(); // real-time sync + index
  } catch (err) {
    console.error("❌ Failed to sync emails:", err);
  }
  console.log(`✅ Server running on http://localhost:${PORT}`);
});

export default app;
