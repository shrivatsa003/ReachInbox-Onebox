import { Inbox, User, Tag } from "lucide-react";

interface SidebarProps {
  selectedAccount: string | null;
  onAccountSelect: (account: string | null) => void;
  selectedCategory: string | null;
  onCategorySelect: (category: string | null) => void;
}

export default function Sidebar({
  selectedAccount,
  onAccountSelect,
  selectedCategory,
  onCategorySelect,
}: SidebarProps) {
  const accounts = ["Account 1", "Account 2"];
  const categories = [
    "Interested",
    "Meeting Booked",
    "Not Interested",
    "Spam",
    "Out of Office",
  ];

  return (
    <aside className="w-64 bg-gray-800 p-4 h-screen flex flex-col">
      <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Inbox className="w-5 h-5" /> Mail Filters
      </h2>

      <div>
        <h3 className="text-sm text-gray-400 uppercase mb-2 flex items-center gap-2">
          <User className="w-4 h-4" /> Accounts
        </h3>
        {accounts.map((acc) => (
          <button
            key={acc}
            onClick={() => onAccountSelect(acc === selectedAccount ? null : acc)}
            className={`block w-full text-left px-3 py-2 rounded-lg mb-1 transition ${
              selectedAccount === acc
                ? "bg-indigo-600 text-white"
                : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            {acc}
          </button>
        ))}
      </div>

      <div className="mt-6">
        <h3 className="text-sm text-gray-400 uppercase mb-2 flex items-center gap-2">
          <Tag className="w-4 h-4" /> Categories
        </h3>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => onCategorySelect(cat === selectedCategory ? null : cat)}
            className={`block w-full text-left px-3 py-2 rounded-lg mb-1 transition ${
              selectedCategory === cat
                ? "bg-indigo-600 text-white"
                : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
    </aside>
  );
}
